package xom.demo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class DateUtil {
	
	public static String dateStart = "11/03/14 08:29:00";
	public static String dateStop = "11/03/14 09:30:01";
 
	public static void main(String[] args) {
		System.out.println("Start - ");
		System.out.println(DateUtil.timeDifference(dateStart, dateStop));
		System.out.println(" - Stop");
	}
	
	public static String timeDifference(String datetimeStart, String datetimeStop){
		// Custom date format
		String dateformat = "yy/MM/dd HH:mm:ss";
		SimpleDateFormat format = new SimpleDateFormat(dateformat);  

		Date d1 = null;
		Date d2 = null;
		try {
		    d1 = format.parse(datetimeStart);
		    d2 = format.parse(datetimeStop);
		} catch (ParseException e) {
			System.out.println("Does the date-time format match " + dateformat + "?");
		    e.printStackTrace();
		}    
		
		return timeDifference(d1, d2);
	}

		
	public static String timeDifference(Date d1, Date d2){	
		String message = "";
		long diff2 = d2.getTime() - d1.getTime();//as given
		long seconds = TimeUnit.MILLISECONDS.toSeconds(diff2);
		long minutes = TimeUnit.MILLISECONDS.toMinutes(diff2); 
		long hours = TimeUnit.MILLISECONDS.toHours(diff2);
		
		message += "Time in seconds: " + seconds + " seconds.\n";    
		message += "Time in minutes: " + minutes + " minutes.\n";         
		message += "Time in hours: " + hours + " hours."; 
		
		return message;
	}

}
